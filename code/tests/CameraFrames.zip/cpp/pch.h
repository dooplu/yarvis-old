//
// Header for standard system include files.
//

#pragma once

#include <collection.h>
#include <ppltasks.h>
#include <shared_mutex>

#include "App.xaml.h"