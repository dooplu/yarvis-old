# samples-large-content

This repo is a submodule of the Windows-universal-samples repo.
It contains the large binary content used by some samples.
